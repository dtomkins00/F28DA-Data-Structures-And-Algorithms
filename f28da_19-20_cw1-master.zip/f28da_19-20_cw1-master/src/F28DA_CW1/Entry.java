package F28DA_CW1;

public class Entry{
	private String word;
	private int position;

	Entry(String word, int position) {
		this.word = word;
		this.position = position;
	}

	public String getWord() {
		return word;
	}

	public int getPosition() {
		return position;
	}
}
